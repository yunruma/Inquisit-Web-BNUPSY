#在Python中生成灰度不一样的图片
from PIL import Image
from pylab import *
im = array(Image.open('fox.jpg').convert('L'))


for i in range(0, 255, 15):
     image = (i/255)*im
     out = Image.fromarray(uint8(image))
     out.save(str(int(i/15)) + ".bmp")
